# CYBR460Assignment5
#   Performing mathematical calculations on an array of numbers using Numpy.

# Set Up
#   1. Open a terminal window on your machine. Please do not close this window as it'll be used in future steps.
#   2. Clone the GitHub repository to your local machine. Repository link: https://github.com/gilbertk23/CYBR460-Assignment5/tree/main
#   3. Navigate to the folder containing the cloned repository.
#   4. Extract the folder's files and open them is Virtual Studio Code.

# Building the Docker Image
#   1. Return to the terminal window.
#   2. Run the following command to build the Docker image: docker build -t NumberInfo .
#       *Note: make sure the "." is entered into the terminal interface; don't leave it out.

# Creating the Docker Container Using the Previously Created Docker Image
#   1. Run the following command to create a Docker container that can run the program using the image you created: docker run -ti NumberInfo
#   2. Please keep the terminal window open.

# Running the Program to Calculate Mathematical Information from the Array
#   1. The "array" variable in the NumberInfo.py file contains 10 values which are used in the calculations by default. If you want, the numerical values in the "array" variable can be changed to whatever integers you'd like.
#   2. Once the "array" values are set to the ones you want, copy your entire current working directory path. This will be used in step #3 to specify where the program's results should be stored.
#   3. Run the following command in the terminal interface to run the program: docker run -v [copied directory path]:/CYBR460Assignment5 -it NumberInfo
#   4. A file titled "arrayCalculations.txt" should be visible in the directory used in step #4. This file contains the calculations performed by the NumberInfo.py file.

#   *Note: the NumberInfo.py program's output is stored in the "arrayCalculations.txt". Its contents are overwritten everytime the NumberInfo.py program runs. If the .txt file is ever missing, running the .py file should recreate it using the "array" variable's values.