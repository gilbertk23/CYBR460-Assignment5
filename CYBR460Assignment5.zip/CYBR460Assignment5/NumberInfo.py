# Imports the numpy library for the program's use.
import numpy as np

# Creates array that will be used by the program. The contents of the array can be changed if wanted.
array = np.array([1, 6, 14, 42, 4, 8, 94, 3, 77, 98])

# Finds the sum of the array's values.
arraySum = np.sum(array)
# Finds the smallest of the array's values.
arrayMin = np.min(array)
# Finds the largest of the array's values.
arrayMax = np.max(array)
# Finds the average of the array's values.
arrayMean = np.mean(array)
# Finds the standard deviation of the array's values.
arrayStandardDev = np.std(array)
# Finds the 25% quartile of the array's values.
array25 = np.quantile(array, 0.25)
# Finds the 75% quartile of the array's values.
array75 = np.quantile(array, 0.75)
# Finds the Interquartile Range (IQR) of the array's values.
arrayIQR = array75 - array25
# Finds the low cutoff for outliers of the array's values.
arrayLowOutlier = array25 - (1.5 * arrayIQR)
# Finds the high cutoff for outliers of the array's values.
arrayHighOutlier = array75 + (1.5 * arrayIQR)

# Converts all calculated values into strings so they can be added to a text file.
arraySum = str(arraySum)
arrayMin = str(arrayMin)
arrayMax = str(arrayMax)
arrayMean = str(arrayMean)
arrayStandardDev = str(arrayStandardDev)
array25 = str(array25)
array75 = str(array75)
arrayIQR = str(arrayIQR)
arrayLowOutlier = str(arrayLowOutlier)
arrayHighOutlier = str(arrayHighOutlier)

# Writes the results of each mathematical value to a text file.
with open("arrayCalculations.txt", "w", encoding="utf-8") as f:
    f.write("Here are some mathematical calculations that\nhave been performed on the array's values.\n")
    f.write("\nSum: ")
    f.write(arraySum)
    f.write("\nSmallest Number: ")
    f.write(arrayMin)
    f.write("\nLargest Number: ")
    f.write(arrayMax)
    f.write("\nMean: ")
    f.write(arrayMean)
    f.write("\nStandard Deviation: ")
    f.write(arrayStandardDev)
    f.write("\n25th Percentile: ")
    f.write(array25)
    f.write("\n75th Percentile: ")
    f.write(array75)
    f.write("\nInterquartile Range: ")
    f.write(arrayIQR)
    f.write("\nLow-End Outliers: Less than ")
    f.write(arrayLowOutlier)
    f.write("\nHigh-End Outliers: Greater than ")
    f.write(arrayHighOutlier)